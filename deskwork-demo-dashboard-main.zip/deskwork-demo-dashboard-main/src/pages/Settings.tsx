import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { RotateCcw, Save, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const defaultSettings = {
  awayMinutes: 5,
  distractedMinutes: 3,
  windowSize: 30,
  minConfidence: 70,
};

export default function Settings() {
  const { toast } = useToast();
  const [settings, setSettings] = useState(defaultSettings);

  const handleSave = () => {
    localStorage.setItem("deskwork-settings", JSON.stringify(settings));
    toast({
      title: "Settings Saved",
      description: "Your settings have been saved locally.",
    });
  };

  const handleReset = () => {
    setSettings(defaultSettings);
    localStorage.removeItem("deskwork-settings");
    toast({
      title: "Settings Reset",
      description: "Settings have been reset to defaults.",
    });
  };

  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      <Navbar />

      <main className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-px w-8 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-primary" />
            <div className="h-px w-8 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Settings</h1>
          <p className="text-sm font-arabic text-primary/80 mt-1">الإعدادات</p>
          <p className="text-muted-foreground mt-1">
            Configure detection thresholds and parameters
          </p>
        </div>

        <div className="card-arabian p-6">
          <div className="space-y-8">
            {/* Away Minutes Threshold */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <Label className="text-base font-medium text-foreground">Away Minutes Threshold</Label>
                  <p className="text-xs font-arabic text-primary/70">حد دقائق الغياب</p>
                </div>
                <span className="text-sm font-medium text-primary">
                  {settings.awayMinutes} minutes
                </span>
              </div>
              <Slider
                value={[settings.awayMinutes]}
                onValueChange={([value]) =>
                  setSettings({ ...settings, awayMinutes: value })
                }
                min={1}
                max={30}
                step={1}
              />
              <p className="text-sm text-muted-foreground mt-2">
                Mark as "Away" after this many consecutive minutes without presence.
              </p>
            </div>

            {/* Distracted Minutes Threshold */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <Label className="text-base font-medium text-foreground">Distracted Minutes Threshold</Label>
                  <p className="text-xs font-arabic text-primary/70">حد دقائق التشتت</p>
                </div>
                <span className="text-sm font-medium text-primary">
                  {settings.distractedMinutes} minutes
                </span>
              </div>
              <Slider
                value={[settings.distractedMinutes]}
                onValueChange={([value]) =>
                  setSettings({ ...settings, distractedMinutes: value })
                }
                min={1}
                max={15}
                step={1}
              />
              <p className="text-sm text-muted-foreground mt-2">
                Mark as "Distracted" after this many minutes not facing screen.
              </p>
            </div>

            {/* Window Size */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <Label className="text-base font-medium text-foreground">Window Size</Label>
                  <p className="text-xs font-arabic text-primary/70">حجم النافذة</p>
                </div>
                <span className="text-sm font-medium text-primary">
                  {settings.windowSize} seconds
                </span>
              </div>
              <Slider
                value={[settings.windowSize]}
                onValueChange={([value]) =>
                  setSettings({ ...settings, windowSize: value })
                }
                min={5}
                max={120}
                step={5}
              />
              <p className="text-sm text-muted-foreground mt-2">
                Rolling window size for averaging detection results.
              </p>
            </div>

            {/* Minimum Confidence */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <div>
                  <Label className="text-base font-medium text-foreground">Minimum Confidence to Flag</Label>
                  <p className="text-xs font-arabic text-primary/70">الحد الأدنى للثقة</p>
                </div>
                <span className="text-sm font-medium text-primary">
                  {settings.minConfidence}%
                </span>
              </div>
              <Slider
                value={[settings.minConfidence]}
                onValueChange={([value]) =>
                  setSettings({ ...settings, minConfidence: value })
                }
                min={50}
                max={100}
                step={5}
              />
              <p className="text-sm text-muted-foreground mt-2">
                Only flag incidents when confidence exceeds this threshold.
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 mt-8 pt-6 border-t border-border">
            <Button onClick={handleSave} className="gap-2 flex-1 btn-gold">
              <Save className="w-4 h-4" />
              Save Settings
            </Button>
            <Button variant="outline" onClick={handleReset} className="gap-2 border-primary/30 hover:bg-primary/10">
              <RotateCcw className="w-4 h-4" />
              Reset to Defaults
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
