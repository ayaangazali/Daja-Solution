import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

interface KPICardProps {
  title: string;
  titleAr?: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    positive: boolean;
  };
  className?: string;
}

export function KPICard({ title, titleAr, value, subtitle, icon: Icon, trend, className }: KPICardProps) {
  return (
    <div className={cn(
      "card-arabian p-6 ornament-corner relative overflow-hidden",
      className
    )}>
      {/* Decorative pattern */}
      <div className="absolute inset-0 bg-pattern-islamic opacity-30 pointer-events-none" />
      
      <div className="relative flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          {titleAr && (
            <p className="text-xs text-primary/70 font-arabic mt-0.5">{titleAr}</p>
          )}
          <p className="mt-3 text-3xl font-bold text-gradient-gold">{value}</p>
          {subtitle && (
            <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p>
          )}
          {trend && (
            <p className={cn(
              "mt-2 text-sm font-medium",
              trend.positive ? "text-accent" : "text-destructive"
            )}>
              {trend.positive ? "↑" : "↓"} {Math.abs(trend.value)}% from yesterday
            </p>
          )}
        </div>
        <div className="p-3 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg border border-primary/20">
          <Icon className="w-6 h-6 text-primary" />
        </div>
      </div>
    </div>
  );
}
