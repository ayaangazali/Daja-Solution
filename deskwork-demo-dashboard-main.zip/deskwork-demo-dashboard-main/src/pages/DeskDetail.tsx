import { useParams, Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { StatusBadge } from "@/components/StatusBadge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, User, Clock, ImageIcon, Star } from "lucide-react";
import { generateTimeline, generateSummarizedBlocks, generateIncidents } from "@/lib/mockData";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

export default function DeskDetail() {
  const { id } = useParams<{ id: string }>();
  const timeline = generateTimeline();
  const blocks = generateSummarizedBlocks();
  const incidents = generateIncidents().filter((inc) => inc.deskId === Number(id)).slice(0, 3);

  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link to="/live">
            <Button variant="ghost" size="sm" className="mb-4 gap-2 text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4" />
              Back to Live Monitor
            </Button>
          </Link>
          <div className="flex items-center gap-2 mb-2">
            <div className="h-px w-8 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-primary" />
            <div className="h-px w-8 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h1 className="text-2xl font-bold text-foreground">Desk {id}</h1>
              <p className="text-sm font-arabic text-primary/80">مكتب {id}</p>
              <div className="flex items-center gap-2 mt-1 text-muted-foreground">
                <User className="w-4 h-4" />
                <span>Assigned to P{id}</span>
              </div>
            </div>
            <StatusBadge status="Working" className="text-sm px-3 py-1" />
          </div>
        </div>

        {/* Timeline Chart */}
        <div className="card-arabian p-6 mb-6">
          <h3 className="font-semibold text-foreground mb-1">Working Score & Confidence Timeline</h3>
          <p className="text-xs font-arabic text-primary/70 mb-4">الجدول الزمني للعمل والثقة</p>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={timeline}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(43 20% 22%)" />
                <XAxis dataKey="time" stroke="hsl(43 20% 60%)" fontSize={12} />
                <YAxis stroke="hsl(43 20% 60%)" fontSize={12} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(30 12% 12%)",
                    border: "1px solid hsl(43 20% 22%)",
                    borderRadius: "0.5rem",
                    color: "hsl(43 30% 90%)",
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="workingScore"
                  name="Working Score"
                  stroke="hsl(43 74% 49%)"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="confidence"
                  name="Confidence"
                  stroke="hsl(160 60% 40%)"
                  strokeWidth={2}
                  strokeDasharray="5 5"
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Summarized Blocks */}
          <div className="card-arabian p-6">
            <h3 className="font-semibold text-foreground mb-1">Summarized Blocks</h3>
            <p className="text-xs font-arabic text-primary/70 mb-4">ملخص الفترات</p>
            <div className="space-y-3">
              {blocks.map((block) => (
                <div
                  key={block.id}
                  className="flex items-center justify-between p-3 bg-secondary/30 rounded-lg border border-border/50"
                >
                  <div className="flex items-center gap-3">
                    <Clock className="w-4 h-4 text-primary" />
                    <span className="text-sm text-foreground">
                      {block.startTime} - {block.endTime}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{block.duration}</span>
                    <StatusBadge status={block.status} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Incidents */}
          <div className="card-arabian p-6">
            <h3 className="font-semibold text-foreground mb-1">Incidents</h3>
            <p className="text-xs font-arabic text-primary/70 mb-4">الحوادث</p>
            {incidents.length > 0 ? (
              <div className="space-y-4">
                {incidents.map((incident) => (
                  <div
                    key={incident.id}
                    className="p-4 border border-border rounded-lg bg-secondary/20"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <span className="font-medium text-foreground">{incident.id}</span>
                        <p className="text-sm text-muted-foreground mt-1">{incident.timestamp}</p>
                      </div>
                      <StatusBadge status={incident.type} />
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{incident.description}</p>
                    <div className="w-full h-24 bg-secondary rounded-lg flex items-center justify-center border border-border/50">
                      <ImageIcon className="w-8 h-8 text-muted-foreground" />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">No incidents for this desk.</p>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
