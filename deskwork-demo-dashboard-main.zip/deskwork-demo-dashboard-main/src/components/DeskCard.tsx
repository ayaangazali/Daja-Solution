import { Link } from "react-router-dom";
import { StatusBadge } from "./StatusBadge";
import { Button } from "@/components/ui/button";
import { Clock, User } from "lucide-react";
import type { Desk } from "@/lib/mockData";

interface DeskCardProps {
  desk: Desk;
}

export function DeskCard({ desk }: DeskCardProps) {
  return (
    <div className="card-arabian p-4 hover:shadow-gold transition-all duration-300 relative overflow-hidden group">
      {/* Decorative corner */}
      <div className="absolute top-0 right-0 w-16 h-16 overflow-hidden">
        <div className="absolute top-0 right-0 w-8 h-8 bg-gradient-to-bl from-primary/20 to-transparent" />
      </div>

      <div className="flex items-start justify-between mb-3">
        <div>
          <h3 className="font-semibold text-foreground">Desk {desk.id}</h3>
          <p className="text-xs text-primary font-arabic">مكتب {desk.id}</p>
          <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
            <User className="w-3 h-3" />
            <span>{desk.personId}</span>
          </div>
        </div>
        <StatusBadge status={desk.status} />
      </div>
      
      <div className="space-y-2 mb-4">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">Confidence</span>
          <span className="font-medium text-foreground">{desk.confidence}%</span>
        </div>
        <div className="w-full bg-secondary rounded-full h-2 overflow-hidden">
          <div 
            className="h-2 rounded-full transition-all bg-gradient-to-r from-primary to-accent"
            style={{ width: `${desk.confidence}%` }}
          />
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="w-3 h-3" />
          <span>Updated {desk.lastUpdate}</span>
        </div>
      </div>

      <Link to={`/desk/${desk.id}`}>
        <Button variant="outline" size="sm" className="w-full border-primary/30 hover:bg-primary/10 hover:border-primary/50">
          View Details
        </Button>
      </Link>
    </div>
  );
}
