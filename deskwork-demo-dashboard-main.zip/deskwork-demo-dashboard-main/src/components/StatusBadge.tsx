import { cn } from "@/lib/utils";
import type { DeskStatus } from "@/lib/mockData";

interface StatusBadgeProps {
  status: DeskStatus;
  className?: string;
}

const statusStyles: Record<DeskStatus, string> = {
  Working: "bg-accent/20 text-accent border-accent/30",
  Away: "bg-primary/20 text-primary border-primary/30",
  Distracted: "bg-destructive/20 text-destructive border-destructive/30",
  Unknown: "bg-muted text-muted-foreground border-muted-foreground/30",
};

const statusArabic: Record<DeskStatus, string> = {
  Working: "يعمل",
  Away: "غائب",
  Distracted: "مشتت",
  Unknown: "غير معروف",
};

export function StatusBadge({ status, className }: StatusBadgeProps) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border",
        statusStyles[status],
        className
      )}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
      {status}
    </span>
  );
}
