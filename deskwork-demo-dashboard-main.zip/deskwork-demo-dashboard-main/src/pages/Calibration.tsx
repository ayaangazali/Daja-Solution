import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Monitor, Square, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Zone {
  id: string;
  name: string;
  type: "desk" | "pc";
}

export default function Calibration() {
  const { toast } = useToast();
  const [zones, setZones] = useState<Zone[]>([
    { id: "1", name: "Desk Zone 1", type: "desk" },
    { id: "2", name: "PC Zone 1", type: "pc" },
    { id: "3", name: "Desk Zone 2", type: "desk" },
  ]);

  const addZone = (type: "desk" | "pc") => {
    const count = zones.filter((z) => z.type === type).length + 1;
    setZones([
      ...zones,
      {
        id: Date.now().toString(),
        name: `${type === "desk" ? "Desk" : "PC"} Zone ${count}`,
        type,
      },
    ]);
  };

  const removeZone = (id: string) => {
    setZones(zones.filter((z) => z.id !== id));
  };

  const updateZoneName = (id: string, name: string) => {
    setZones(zones.map((z) => (z.id === id ? { ...z, name } : z)));
  };

  const handleSave = () => {
    toast({
      title: "Saved locally (demo)",
      description: "Calibration settings have been saved to local state.",
    });
  };

  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-px w-8 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-primary" />
            <div className="h-px w-8 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Calibration</h1>
          <p className="text-sm font-arabic text-primary/80 mt-1">المعايرة</p>
          <p className="text-muted-foreground mt-1">
            Configure desk and PC zones for monitoring
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Office Snapshot */}
          <div className="lg:col-span-2 card-arabian p-6">
            <h3 className="font-semibold text-foreground mb-1">Office Snapshot</h3>
            <p className="text-xs font-arabic text-primary/70 mb-4">لقطة المكتب</p>
            <div className="aspect-video bg-secondary/30 rounded-lg flex items-center justify-center border-2 border-dashed border-border">
              <div className="text-center">
                <Monitor className="w-16 h-16 mx-auto text-primary/50 mb-3" />
                <p className="text-muted-foreground">
                  Office camera snapshot placeholder
                </p>
                <p className="text-xs font-arabic text-primary/50 mt-1">
                  عرض الكاميرا هنا
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  In production, draw zones directly on the image
                </p>
              </div>
            </div>
          </div>

          {/* Zone List */}
          <div className="card-arabian p-6">
            <h3 className="font-semibold text-foreground mb-1">Configured Zones</h3>
            <p className="text-xs font-arabic text-primary/70 mb-4">المناطق المحددة</p>

            <div className="space-y-4 mb-6">
              {zones.map((zone) => (
                <div
                  key={zone.id}
                  className="flex items-center gap-2 p-3 bg-secondary/30 rounded-lg border border-border/50"
                >
                  <div
                    className={`w-8 h-8 rounded flex items-center justify-center ${
                      zone.type === "desk"
                        ? "bg-primary/20 text-primary"
                        : "bg-accent/20 text-accent"
                    }`}
                  >
                    {zone.type === "desk" ? (
                      <Square className="w-4 h-4" />
                    ) : (
                      <Monitor className="w-4 h-4" />
                    )}
                  </div>
                  <Input
                    value={zone.name}
                    onChange={(e) => updateZoneName(zone.id, e.target.value)}
                    className="flex-1 h-8 bg-secondary border-border"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    onClick={() => removeZone(zone.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full justify-start gap-2 border-primary/30 hover:bg-primary/10"
                onClick={() => addZone("desk")}
              >
                <Plus className="w-4 h-4" />
                Add Desk Zone
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start gap-2 border-accent/30 hover:bg-accent/10"
                onClick={() => addZone("pc")}
              >
                <Plus className="w-4 h-4" />
                Add PC Zone
              </Button>
            </div>

            <div className="mt-6 pt-6 border-t border-border">
              <Button onClick={handleSave} className="w-full btn-gold">
                Save Configuration
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
