import { Navbar } from "@/components/Navbar";
import { KPICard } from "@/components/KPICard";
import { DataTable } from "@/components/DataTable";
import { StatusBadge } from "@/components/StatusBadge";
import { Monitor, TrendingUp, AlertTriangle, Target, Star } from "lucide-react";
import { 
  getDashboardKPIs, 
  getWorkingScoreTrend, 
  getIncidentsByType,
  generateIncidents,
  type Incident
} from "@/lib/mockData";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar
} from "recharts";

export default function Dashboard() {
  const kpis = getDashboardKPIs();
  const workingTrend = getWorkingScoreTrend();
  const incidentsByType = getIncidentsByType();
  const recentIncidents = generateIncidents().slice(0, 5);

  const incidentColumns = [
    { key: 'id', header: 'ID' },
    { key: 'deskId', header: 'Desk', render: (item: Incident) => `Desk ${item.deskId}` },
    { 
      key: 'type', 
      header: 'Type',
      render: (item: Incident) => <StatusBadge status={item.type} />
    },
    { key: 'timestamp', header: 'Time' },
    { key: 'duration', header: 'Duration' },
  ];

  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-px w-8 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-primary" />
            <div className="h-px w-8 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Dashboard Overview</h1>
          <p className="text-sm font-arabic text-primary/80 mt-1">نظرة عامة على لوحة القيادة</p>
          <p className="text-muted-foreground mt-1">Monitor your workspace activity at a glance</p>
        </div>

        {/* KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <KPICard
            title="Desks Monitored"
            titleAr="المكاتب المراقبة"
            value={kpis.desksMonitored}
            icon={Monitor}
          />
          <KPICard
            title="Working % Today"
            titleAr="نسبة العمل اليوم"
            value={`${kpis.workingPercent}%`}
            icon={TrendingUp}
            trend={{ value: 3, positive: true }}
          />
          <KPICard
            title="Incidents Today"
            titleAr="الحوادث اليوم"
            value={kpis.incidentsToday}
            icon={AlertTriangle}
            trend={{ value: 2, positive: false }}
          />
          <KPICard
            title="Avg Confidence"
            titleAr="متوسط الثقة"
            value={`${kpis.avgConfidence}%`}
            icon={Target}
          />
        </div>

        {/* Charts */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          {/* Working Score Trend */}
          <div className="card-arabian p-6">
            <h3 className="font-semibold text-foreground mb-1">Working Score Trend</h3>
            <p className="text-xs font-arabic text-primary/70 mb-4">اتجاه درجة العمل</p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={workingTrend}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(43 20% 22%)" />
                  <XAxis dataKey="day" stroke="hsl(43 20% 60%)" fontSize={12} />
                  <YAxis stroke="hsl(43 20% 60%)" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(30 12% 12%)',
                      border: '1px solid hsl(43 20% 22%)',
                      borderRadius: '0.5rem',
                      color: 'hsl(43 30% 90%)'
                    }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="score" 
                    stroke="hsl(43 74% 49%)" 
                    strokeWidth={2}
                    dot={{ fill: 'hsl(43 74% 49%)' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Incidents by Type */}
          <div className="card-arabian p-6">
            <h3 className="font-semibold text-foreground mb-1">Incidents by Type</h3>
            <p className="text-xs font-arabic text-primary/70 mb-4">الحوادث حسب النوع</p>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={incidentsByType}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(43 20% 22%)" />
                  <XAxis dataKey="type" stroke="hsl(43 20% 60%)" fontSize={12} />
                  <YAxis stroke="hsl(43 20% 60%)" fontSize={12} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'hsl(30 12% 12%)',
                      border: '1px solid hsl(43 20% 22%)',
                      borderRadius: '0.5rem',
                      color: 'hsl(43 30% 90%)'
                    }}
                  />
                  <Bar 
                    dataKey="count" 
                    fill="hsl(43 74% 49%)" 
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Recent Incidents Table */}
        <div className="card-arabian p-6">
          <h3 className="font-semibold text-foreground mb-1">Recent Incidents</h3>
          <p className="text-xs font-arabic text-primary/70 mb-4">الحوادث الأخيرة</p>
          <DataTable data={recentIncidents} columns={incidentColumns} />
        </div>
      </main>
    </div>
  );
}
