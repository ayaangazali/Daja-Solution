import { useState, useMemo } from "react";
import { Navbar } from "@/components/Navbar";
import { DeskCard } from "@/components/DeskCard";
import { generateDesks } from "@/lib/mockData";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Star } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function LiveMonitor() {
  const [desks] = useState(generateDesks);
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [minConfidence, setMinConfidence] = useState(0);

  const filteredDesks = useMemo(() => {
    return desks.filter((desk) => {
      const matchesStatus = statusFilter === "all" || desk.status === statusFilter;
      const matchesConfidence = desk.confidence >= minConfidence;
      return matchesStatus && matchesConfidence;
    });
  }, [desks, statusFilter, minConfidence]);

  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-px w-8 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-primary" />
            <div className="h-px w-8 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Live Monitor</h1>
          <p className="text-sm font-arabic text-primary/80 mt-1">المراقبة المباشرة</p>
          <p className="text-muted-foreground mt-1">Real-time desk status monitoring</p>
        </div>

        {/* Filters */}
        <div className="card-arabian p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-6">
            <div className="flex-1 max-w-xs">
              <Label className="text-sm font-medium mb-2 block text-foreground">Status Filter</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="bg-secondary border-border">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-card border-border">
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="Working">Working</SelectItem>
                  <SelectItem value="Away">Away</SelectItem>
                  <SelectItem value="Distracted">Distracted</SelectItem>
                  <SelectItem value="Unknown">Unknown</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 max-w-xs">
              <Label className="text-sm font-medium mb-2 block text-foreground">
                Min Confidence: {minConfidence}%
              </Label>
              <Slider
                value={[minConfidence]}
                onValueChange={([value]) => setMinConfidence(value)}
                max={100}
                step={5}
                className="mt-3"
              />
            </div>
          </div>
        </div>

        {/* Desk Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filteredDesks.map((desk) => (
            <DeskCard key={desk.id} desk={desk} />
          ))}
        </div>

        {filteredDesks.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <p>No desks match the current filters.</p>
            <p className="text-sm font-arabic text-primary/60 mt-1">لا توجد مكاتب مطابقة</p>
          </div>
        )}
      </main>
    </div>
  );
}
