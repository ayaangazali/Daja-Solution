export type DeskStatus = 'Working' | 'Away' | 'Distracted' | 'Unknown';

export interface Desk {
  id: number;
  personId: string;
  status: DeskStatus;
  confidence: number;
  lastUpdate: string;
}

export interface Incident {
  id: string;
  deskId: number;
  type: 'Away' | 'Distracted' | 'Unknown';
  timestamp: string;
  duration: string;
  description: string;
}

export interface TimelinePoint {
  time: string;
  workingScore: number;
  confidence: number;
}

export interface SummarizedBlock {
  id: string;
  startTime: string;
  endTime: string;
  status: DeskStatus;
  duration: string;
}

export interface ArchivedVideo {
  id: string;
  date: string;
  camera: string;
  duration: string;
  processed: boolean;
  status: 'Completed' | 'Processing' | 'Pending';
}

export interface Report {
  id: string;
  generatedAt: string;
  dateRange: string;
  recipient: string;
  status: 'Sent' | 'Pending';
}

// Generate mock desks
export const generateDesks = (): Desk[] => {
  const statuses: DeskStatus[] = ['Working', 'Away', 'Distracted', 'Unknown'];
  return Array.from({ length: 12 }, (_, i) => ({
    id: i + 1,
    personId: `P${i + 1}`,
    status: statuses[Math.floor(Math.random() * statuses.length)],
    confidence: Math.floor(Math.random() * 30) + 70,
    lastUpdate: new Date(Date.now() - Math.floor(Math.random() * 3600000)).toLocaleTimeString(),
  }));
};

// Generate mock incidents
export const generateIncidents = (): Incident[] => {
  const types: ('Away' | 'Distracted' | 'Unknown')[] = ['Away', 'Distracted', 'Unknown'];
  return Array.from({ length: 8 }, (_, i) => ({
    id: `INC-${1000 + i}`,
    deskId: Math.floor(Math.random() * 12) + 1,
    type: types[Math.floor(Math.random() * types.length)],
    timestamp: new Date(Date.now() - Math.floor(Math.random() * 86400000)).toLocaleString(),
    duration: `${Math.floor(Math.random() * 30) + 5} min`,
    description: `${types[Math.floor(Math.random() * types.length)]} detected at desk`,
  }));
};

// Generate mock timeline data
export const generateTimeline = (): TimelinePoint[] => {
  return Array.from({ length: 24 }, (_, i) => ({
    time: `${String(i).padStart(2, '0')}:00`,
    workingScore: Math.floor(Math.random() * 40) + 60,
    confidence: Math.floor(Math.random() * 20) + 80,
  }));
};

// Generate mock summarized blocks
export const generateSummarizedBlocks = (): SummarizedBlock[] => {
  const statuses: DeskStatus[] = ['Working', 'Away', 'Distracted', 'Working'];
  return [
    { id: '1', startTime: '08:00', endTime: '10:30', status: 'Working', duration: '2h 30m' },
    { id: '2', startTime: '10:30', endTime: '10:45', status: 'Away', duration: '15m' },
    { id: '3', startTime: '10:45', endTime: '12:00', status: 'Working', duration: '1h 15m' },
    { id: '4', startTime: '12:00', endTime: '13:00', status: 'Away', duration: '1h' },
    { id: '5', startTime: '13:00', endTime: '14:30', status: 'Working', duration: '1h 30m' },
    { id: '6', startTime: '14:30', endTime: '14:45', status: 'Distracted', duration: '15m' },
    { id: '7', startTime: '14:45', endTime: '17:00', status: 'Working', duration: '2h 15m' },
  ];
};

// Generate archived videos
export const generateArchivedVideos = (): ArchivedVideo[] => {
  return [
    { id: 'VID-001', date: '2024-01-15', camera: 'Camera A', duration: '8h 00m', processed: true, status: 'Completed' },
    { id: 'VID-002', date: '2024-01-14', camera: 'Camera B', duration: '7h 45m', processed: true, status: 'Completed' },
    { id: 'VID-003', date: '2024-01-13', camera: 'Camera A', duration: '8h 15m', processed: true, status: 'Completed' },
    { id: 'VID-004', date: '2024-01-12', camera: 'Camera C', duration: '6h 30m', processed: false, status: 'Processing' },
    { id: 'VID-005', date: '2024-01-11', camera: 'Camera B', duration: '8h 00m', processed: true, status: 'Completed' },
  ];
};

// Generate reports
export const generateReports = (): Report[] => {
  return [
    { id: 'RPT-001', generatedAt: '2024-01-15 09:00', dateRange: 'Jan 8 - Jan 14', recipient: 'manager@company.com', status: 'Sent' },
    { id: 'RPT-002', generatedAt: '2024-01-08 09:00', dateRange: 'Jan 1 - Jan 7', recipient: 'manager@company.com', status: 'Sent' },
    { id: 'RPT-003', generatedAt: '2024-01-01 09:00', dateRange: 'Dec 25 - Dec 31', recipient: 'hr@company.com', status: 'Sent' },
  ];
};

// Dashboard KPI data
export const getDashboardKPIs = () => ({
  desksMonitored: 12,
  workingPercent: 78,
  incidentsToday: 5,
  avgConfidence: 89,
});

// Working score trend data
export const getWorkingScoreTrend = () => [
  { day: 'Mon', score: 82 },
  { day: 'Tue', score: 78 },
  { day: 'Wed', score: 85 },
  { day: 'Thu', score: 80 },
  { day: 'Fri', score: 76 },
  { day: 'Sat', score: 45 },
  { day: 'Sun', score: 30 },
];

// Incidents by type data
export const getIncidentsByType = () => [
  { type: 'Away', count: 24 },
  { type: 'Distracted', count: 12 },
  { type: 'Unknown', count: 6 },
];
