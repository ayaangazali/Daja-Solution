import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { 
  Monitor, 
  BarChart3, 
  Upload, 
  Archive, 
  FileText, 
  Shield,
  ArrowRight,
  Check,
  Star
} from "lucide-react";

const features = [
  {
    icon: Monitor,
    title: "Real-time Review",
    titleAr: "مراجعة مباشرة",
    description: "Monitor desk presence and screen attention in real-time with live status updates.",
  },
  {
    icon: Upload,
    title: "Upload MP4",
    titleAr: "رفع الفيديو",
    description: "Process historical footage by uploading MP4 files for batch analysis.",
  },
  {
    icon: Archive,
    title: "Archive Access",
    titleAr: "الوصول للأرشيف",
    description: "Browse and analyze past recordings with full search capabilities.",
  },
  {
    icon: BarChart3,
    title: "Dashboard Analytics",
    titleAr: "تحليلات اللوحة",
    description: "Comprehensive analytics with trends, patterns, and actionable insights.",
  },
  {
    icon: FileText,
    title: "PDF/Email Reports",
    titleAr: "تقارير البريد",
    description: "Generate and send detailed reports automatically to stakeholders.",
  },
  {
    icon: Shield,
    title: "Confidence Scoring",
    titleAr: "تسجيل الثقة",
    description: "AI-powered confidence metrics ensure accurate presence detection.",
  },
];

const pricingPlans = [
  {
    name: "Starter",
    nameAr: "البداية",
    price: "$99",
    period: "/month",
    description: "For small teams getting started",
    features: ["Up to 10 desks", "Real-time monitoring", "Basic reports", "Email support"],
  },
  {
    name: "Professional",
    nameAr: "المحترف",
    price: "$299",
    period: "/month",
    description: "For growing organizations",
    features: ["Up to 50 desks", "Advanced analytics", "Custom reports", "Priority support", "API access"],
    popular: true,
  },
  {
    name: "Enterprise",
    nameAr: "المؤسسة",
    price: "Custom",
    period: "",
    description: "For large deployments",
    features: ["Unlimited desks", "Custom integrations", "Dedicated support", "SLA guarantee", "On-premise option"],
  },
];

export default function Index() {
  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      {/* Hero Section */}
      <header className="border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-gradient-to-br from-primary to-accent shadow-gold">
              <Monitor className="w-5 h-5 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="font-semibold text-foreground">DeskWork Analytics</span>
              <span className="text-xs text-primary font-arabic">تحليلات المكتب</span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline-flex px-3 py-1 text-xs font-medium bg-primary/20 text-primary rounded-full border border-primary/30">
              ✧ Demo Mode ✧
            </span>
            <Link to="/dashboard">
              <Button variant="outline" size="sm" className="border-primary/30 hover:bg-primary/10">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <main>
        {/* Hero */}
        <section className="py-20 lg:py-28 relative overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-20 left-10 w-32 h-32 bg-primary/10 rounded-full blur-3xl" />
          <div className="absolute bottom-20 right-10 w-40 h-40 bg-accent/10 rounded-full blur-3xl" />
          
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative">
            {/* Arabic ornament */}
            <div className="flex items-center justify-center gap-2 mb-6">
              <div className="h-px w-16 bg-gradient-to-r from-transparent to-primary" />
              <Star className="w-4 h-4 text-primary" />
              <div className="h-px w-16 bg-gradient-to-l from-transparent to-primary" />
            </div>
            
            <h1 className="text-4xl lg:text-5xl font-bold text-foreground leading-tight max-w-3xl mx-auto">
              Monitor desk presence and screen-facing attention — 
              <span className="text-gradient-gold"> with confidence.</span>
            </h1>
            
            <p className="mt-4 text-xl font-arabic text-primary/80">
              مراقبة حضور المكتب بثقة
            </p>
            
            <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
              DeskWork Analytics provides enterprise-grade workspace monitoring with AI-powered 
              presence detection, real-time alerts, and comprehensive reporting.
            </p>
            
            <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/dashboard">
                <Button size="lg" className="gap-2 btn-gold">
                  View Demo Dashboard
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link to="/calibration">
                <Button variant="outline" size="lg" className="border-primary/30 hover:bg-primary/10">
                  Calibrate Desks
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-20 bg-secondary/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-foreground">Powerful Features</h2>
              <p className="text-lg font-arabic text-primary/80 mt-2">ميزات قوية</p>
              <p className="mt-3 text-muted-foreground">Everything you need to monitor workspace productivity</p>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {features.map((feature) => {
                const Icon = feature.icon;
                return (
                  <div key={feature.title} className="card-arabian p-6 hover:shadow-gold transition-all duration-300 group">
                    <div className="w-12 h-12 bg-gradient-to-br from-primary/20 to-accent/20 rounded-lg flex items-center justify-center mb-4 border border-primary/20 group-hover:border-primary/40 transition-colors">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <h3 className="font-semibold text-foreground mb-1">{feature.title}</h3>
                    <p className="text-xs font-arabic text-primary/70 mb-2">{feature.titleAr}</p>
                    <p className="text-sm text-muted-foreground">{feature.description}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Pricing */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-foreground">Simple Pricing</h2>
              <p className="text-lg font-arabic text-primary/80 mt-2">أسعار بسيطة</p>
              <p className="mt-3 text-muted-foreground">Choose the plan that fits your organization</p>
            </div>
            <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              {pricingPlans.map((plan) => (
                <div 
                  key={plan.name} 
                  className={`card-arabian p-6 relative ${
                    plan.popular ? 'ring-2 ring-primary shadow-gold-lg' : ''
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                      <span className="bg-gradient-to-r from-primary to-accent text-primary-foreground text-xs font-medium px-4 py-1 rounded-full">
                        ✧ Most Popular ✧
                      </span>
                    </div>
                  )}
                  <div className="text-center mb-6">
                    <h3 className="font-semibold text-foreground mb-1">{plan.name}</h3>
                    <p className="text-xs font-arabic text-primary/70">{plan.nameAr}</p>
                    <div className="flex items-baseline justify-center gap-1 mt-3">
                      <span className="text-3xl font-bold text-gradient-gold">{plan.price}</span>
                      <span className="text-muted-foreground">{plan.period}</span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">{plan.description}</p>
                  </div>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4 text-accent flex-shrink-0" />
                        <span className="text-foreground">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button 
                    className={`w-full ${plan.popular ? 'btn-gold' : 'border-primary/30 hover:bg-primary/10'}`}
                    variant={plan.popular ? "default" : "outline"}
                  >
                    Get Started
                  </Button>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-12 bg-card/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-gradient-to-br from-primary to-accent">
                <Monitor className="w-4 h-4 text-primary-foreground" />
              </div>
              <div>
                <span className="font-medium text-foreground">DeskWork Analytics</span>
                <p className="text-xs text-primary font-arabic">تحليلات المكتب</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 DeskWork Analytics. All rights reserved.
            </p>
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <a href="#" className="hover:text-primary transition-colors">Privacy</a>
              <a href="#" className="hover:text-primary transition-colors">Terms</a>
              <a href="#" className="hover:text-primary transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
