import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { DataTable } from "@/components/DataTable";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Send, Download, FileText, Star } from "lucide-react";
import { generateReports, type Report } from "@/lib/mockData";
import { useToast } from "@/hooks/use-toast";

export default function Reports() {
  const { toast } = useToast();
  const [reports] = useState(generateReports);
  const [startDate, setStartDate] = useState("2024-01-08");
  const [endDate, setEndDate] = useState("2024-01-14");
  const [email, setEmail] = useState("");

  const handleGenerate = () => {
    if (!email) {
      toast({
        title: "Email Required",
        description: "Please enter a recipient email address.",
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Report Generated (Demo)",
      description: `PDF report sent to ${email} for ${startDate} to ${endDate}.`,
    });
  };

  const columns = [
    { key: "id", header: "Report ID" },
    { key: "generatedAt", header: "Generated At" },
    { key: "dateRange", header: "Date Range" },
    { key: "recipient", header: "Recipient" },
    {
      key: "status",
      header: "Status",
      render: (item: Report) => (
        <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-accent/20 text-accent">
          {item.status}
        </span>
      ),
    },
    {
      key: "actions",
      header: "Actions",
      render: (item: Report) => (
        <Button
          variant="outline"
          size="sm"
          className="gap-1 border-primary/30 hover:bg-primary/10"
          onClick={() =>
            toast({
              title: "Demo Mode",
              description: "Download is a demo feature.",
            })
          }
        >
          <Download className="w-3 h-3" />
          Download
        </Button>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-px w-8 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-primary" />
            <div className="h-px w-8 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Reports</h1>
          <p className="text-sm font-arabic text-primary/80 mt-1">التقارير</p>
          <p className="text-muted-foreground mt-1">
            Generate and send analytics reports
          </p>
        </div>

        {/* Report Generator */}
        <div className="card-arabian p-6 mb-8">
          <div className="flex items-center gap-2 mb-6">
            <FileText className="w-5 h-5 text-primary" />
            <h3 className="font-semibold text-foreground">Generate New Report</h3>
            <span className="text-xs font-arabic text-primary/70">إنشاء تقرير جديد</span>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div>
              <Label className="mb-2 block text-foreground">Start Date</Label>
              <div className="relative">
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="bg-secondary border-border"
                />
              </div>
            </div>

            <div>
              <Label className="mb-2 block text-foreground">End Date</Label>
              <div className="relative">
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="bg-secondary border-border"
                />
              </div>
            </div>

            <div className="sm:col-span-2">
              <Label className="mb-2 block text-foreground">Recipient Email</Label>
              <Input
                type="email"
                placeholder="manager@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-secondary border-border"
              />
            </div>
          </div>

          <Button onClick={handleGenerate} className="gap-2 btn-gold">
            <Send className="w-4 h-4" />
            Generate PDF & Send Email
          </Button>

          <p className="text-xs text-muted-foreground mt-4">
            Note: In demo mode, no actual email is sent.
          </p>
        </div>

        {/* Reports History */}
        <div className="card-arabian p-6">
          <h3 className="font-semibold text-foreground mb-1">Generated Reports</h3>
          <p className="text-xs font-arabic text-primary/70 mb-4">التقارير المُنشأة</p>
          <DataTable data={reports} columns={columns} />
        </div>
      </main>
    </div>
  );
}
