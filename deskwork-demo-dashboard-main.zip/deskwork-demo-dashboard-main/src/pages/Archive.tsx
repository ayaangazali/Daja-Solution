import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { DataTable } from "@/components/DataTable";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Upload, FileVideo, Check, Loader2, Star } from "lucide-react";
import { generateArchivedVideos, type ArchivedVideo } from "@/lib/mockData";
import { useToast } from "@/hooks/use-toast";

export default function Archive() {
  const { toast } = useToast();
  const [archivedVideos] = useState(generateArchivedVideos);
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const [progress, setProgress] = useState(0);

  const handleFileDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.name.endsWith(".mp4")) {
      startProcessing(file.name);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      startProcessing(file.name);
    }
  };

  const startProcessing = (fileName: string) => {
    setUploadedFile(fileName);
    setProcessing(true);
    setProgress(0);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setProcessing(false);
          toast({
            title: "Processing Complete",
            description: `${fileName} has been processed successfully (demo).`,
          });
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  const columns = [
    { key: "id", header: "ID" },
    { key: "date", header: "Date" },
    { key: "camera", header: "Camera" },
    { key: "duration", header: "Duration" },
    {
      key: "status",
      header: "Status",
      render: (item: ArchivedVideo) => (
        <span
          className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${
            item.status === "Completed"
              ? "bg-accent/20 text-accent"
              : item.status === "Processing"
              ? "bg-primary/20 text-primary"
              : "bg-muted text-muted-foreground"
          }`}
        >
          {item.status === "Processing" && <Loader2 className="w-3 h-3 animate-spin" />}
          {item.status === "Completed" && <Check className="w-3 h-3" />}
          {item.status}
        </span>
      ),
    },
    {
      key: "actions",
      header: "Actions",
      render: (item: ArchivedVideo) => (
        <Button
          variant="outline"
          size="sm"
          disabled={!item.processed}
          className="border-primary/30 hover:bg-primary/10"
          onClick={() =>
            toast({
              title: "Demo Mode",
              description: "View Results is a demo feature.",
            })
          }
        >
          View Results
        </Button>
      ),
    },
  ];

  return (
    <div className="min-h-screen bg-background bg-pattern-islamic">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <div className="h-px w-8 bg-gradient-to-r from-transparent to-primary" />
            <Star className="w-3 h-3 text-primary" />
            <div className="h-px w-8 bg-gradient-to-l from-transparent to-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground">Archive</h1>
          <p className="text-sm font-arabic text-primary/80 mt-1">الأرشيف</p>
          <p className="text-muted-foreground mt-1">Upload and manage historical footage</p>
        </div>

        {/* Upload Widget */}
        <div className="card-arabian p-6 mb-8">
          <h3 className="font-semibold text-foreground mb-1">Upload MP4</h3>
          <p className="text-xs font-arabic text-primary/70 mb-4">رفع ملف فيديو</p>
          <div
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleFileDrop}
            className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors bg-secondary/20"
          >
            {!uploadedFile ? (
              <>
                <Upload className="w-12 h-12 mx-auto text-primary mb-4" />
                <p className="text-foreground font-medium mb-2">
                  Drag and drop an MP4 file here
                </p>
                <p className="text-xs font-arabic text-primary/60 mb-2">اسحب وأفلت ملف MP4 هنا</p>
                <p className="text-sm text-muted-foreground mb-4">or</p>
                <label>
                  <input
                    type="file"
                    accept=".mp4"
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                  <Button variant="outline" className="border-primary/30 hover:bg-primary/10" asChild>
                    <span>Browse Files</span>
                  </Button>
                </label>
              </>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <FileVideo className="w-6 h-6 text-primary" />
                  <span className="font-medium text-foreground">{uploadedFile}</span>
                </div>
                {processing ? (
                  <div className="max-w-md mx-auto">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-muted-foreground">Processing...</span>
                      <span className="text-primary font-medium">{progress}%</span>
                    </div>
                    <Progress value={progress} className="h-2" />
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-2 text-accent">
                    <Check className="w-5 h-5" />
                    <span className="font-medium">Processing Complete</span>
                  </div>
                )}
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-3">
            Note: In demo mode, files are not actually uploaded.
          </p>
        </div>

        {/* Archive Table */}
        <div className="card-arabian p-6">
          <h3 className="font-semibold text-foreground mb-1">Archived Videos</h3>
          <p className="text-xs font-arabic text-primary/70 mb-4">الفيديوهات المؤرشفة</p>
          <DataTable data={archivedVideos} columns={columns} />
        </div>
      </main>
    </div>
  );
}
